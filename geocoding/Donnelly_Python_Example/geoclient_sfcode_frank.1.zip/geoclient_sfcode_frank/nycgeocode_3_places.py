#This script was created subsequent to nyc_geocode2, which was used to match the
#unmatched stop and frisk records. Records that were output from that process
#were borught into this one is they had an error message indicating a Non-addressable
#place name - these were landmarks; usually parks. They were re-rerun and matched using
#The API's place function
#Frank Donnelly Geospatial Data Librarian Baruch CUNY

#Last updated May 22, 2015

from nyc_geoclient import Geoclient

#Function matches an NYC landmark via api; had to check to see if there was a x coordinate -
#all place matches return a message, so message could not be used to determine if a match was
#sucessful or not. If no match is found, error message is returned
def getplace(row,lmark,borough,x,y):
    cred=Geoclient('YOUR_APP_ID', 'YOUR_APP_KEY')
    geocode=cred.place(row[lmark],row[borough])
    if geocode.get('xCoordinate')!=None:
        row[x]=geocode.get('xCoordinate')
        row[y]=geocode.get('yCoordinate')
        lmarkname=geocode.get('firstStreetNameNormalized')
        row[-1]='*MATCHED - TO CENTER OF LANDMARK - '+str('MISSING' if lmarkname is None else lmarkname)
    else:
        row[-1]=geocode.get('message')
    return row

#The primary function for the script. Takes file name and the indexes or columns
#numbers in the input file as input. Reads lines into nested list if records have
#that error message - had to strip some blanks in certain files to get this to work
def sfplace(thefile,street,instreet,crstreet,borough,x,y):    
    records=[]
    readfile=open(thefile,"r")
    header=readfile.readline().strip().split(",")
    records.append(header)
    for line in readfile:
        line_list=line.strip().split(",")
        while line_list[-1]=='':
            line_list.pop()
        if line_list[-1]=='NON-ADDRESSABLE PLACE NAME PROCESSING IS NOT AVAILABLE FOR THIS FUNCTION':
            records.append(line_list)
    readfile.close()


#Loop through the records and pass the relevant values to the geocoder functions in order                   
#to test for the presence of a landmark in each of the three street fields.
#The sub-if statements will attempt to rematch if a match is not found; before passing
#the info back the error message from the last process is removed.                    
    counter=0   
    for row in records[1:]:                
        if row[street] !='':
            getplace(row,street,borough,x,y)
            if row[-1].startswith('*MATCHED')==False:
                getplace(row,instreet,borough,x,y)
                if row[-1].startswith('*MATCHED')==False:
                    getplace(row,crstreet,borough,x,y)  
        elif row[instreet] !='':
            getplace(row,instreet,borough,x,y)
            if row[-1].startswith('*MATCHED')==False:
                getplace(row,crstreet,borough,x,y)
        elif row[crstreet] !='':
            getplace(row,crstreet,borough,x,y)
        else:
            pass
        counter=counter+1
        if counter % 500 ==0:
            print counter, "records have been processed so far."

    print "A total of", counter, "records have been processed."

            
#Write the records out to a new file with a name modified from the original          
    writefile=open('placematched_2006.csv',"a")
    for row in records:        
        writefile.writelines(",".join(row)+"\n")   
    writefile.close()


            
