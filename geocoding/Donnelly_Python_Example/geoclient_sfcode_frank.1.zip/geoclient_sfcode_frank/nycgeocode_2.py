#Processes and geocodes missing coordinate records from NYPD stop and frisk data
#using the geoclient api from NYC DOITT
#Last updated May 13, 2015
#Frank Donnelly Geospatial Data Librarian Baruch CUNY

from nyc_geoclient import Geoclient

#Function matches an address via api; had to add some conditions due to a couple of
#exceptional address records that have no real address (in Queens Midtown Tunnel)
#If no match is found, error message is returned
def getaddress(row,adnum,street,borough,x,y):
    cred=Geoclient('YOUR_APP_ID', 'YOUR_APP_KEY')
    geocode=cred.address(row[adnum], row[street], row[borough])
    if geocode.get('message')==None:
        row[x]=geocode.get('xCoordinate')
        row[y]=geocode.get('yCoordinate')
        addrhouse=geocode.get('houseNumber')
        addrstreet=geocode.get('firstStreetNameNormalized')        
        row.append('*MATCHED - TO ADDRESS - '+str('MISSING' if addrhouse is None else addrhouse)
                   +' '+str('MISSING' if addrstreet is None else addrstreet))
    else:
        row.append(geocode.get('message'))
    return row

#Function retrieves start and end coordinates of a street between two other streets
#via the api and calculates the midpoint. Returns error message if no match is found
def getblock(row,street,instreet,crstreet,borough,x,y):
    cred=Geoclient('YOUR_APP_ID', 'YOUR_APP_KEY')
    geocode=cred.blockface(row[street],row[instreet],row[crstreet],row[borough])    
    if geocode.get('message')==None:
        from_x=geocode.get('fromXCoordinate')
        to_x=geocode.get('toXCoordinate')
        from_y=geocode.get('fromYCoordinate')
        to_y=geocode.get('toYCoordinate')
        midx=(int(from_x)+int(to_x))/2
        midy=(int(from_y)+int(to_y))/2
        row[x]= str(midx)
        row[y]= str(midy)
        row.append('*MATCHED - TO BLOCK MIDPOINT - '+geocode.get('firstStreetNameNormalized')+' BEWTEEN '
                   +geocode.get('secondStreetNameNormalized')+' AND '+geocode.get('thirdStreetNameNormalized'))
    else:
        row.append(geocode.get('message'))
    return row

#Function returns the intersection of two streets via the api. If an error code is returned
#that streets don't interesect but are separated by small distance, a compass coordinate
#is provided. Returns error message if no match is found
def getintersection(row,street1,street2,borough,x,y):
    cred=Geoclient('YOUR_APP_ID', 'YOUR_APP_KEY')
    geocode=cred.intersection(row[street1], row[street2], row[borough])
    if geocode.get('message')==None:
        row[x]=geocode.get('xCoordinate')
        row[y]=geocode.get('yCoordinate')
        row.append('*MATCHED - TO INTERSECTION - '+geocode.get('firstStreetNameNormalized')+' AND '
                   +geocode.get('secondStreetNameNormalized'))
    elif geocode.get('geosupportFunctionCode')=='2' and geocode.get('geosupportReturnCode')=='02':
        geocode=cred.intersection(row[street1], row[street2], row[borough],compassDirection='N')
        if geocode.get('message')==None:
            row[x]=geocode.get('xCoordinate')
            row[y]=geocode.get('yCoordinate')
            row.append('*MATCHED - TO INTERSECTION - '+geocode.get('firstStreetNameNormalized')+' AND '
                   +geocode.get('secondStreetNameNormalized'))        
        elif geocode.get('geosupportFunctionCode')=='2' and geocode.get('geosupportReturnCode')=='02':
            geocode=cred.intersection(row[street1], row[street2], row[borough],compassDirection='E')
            row[x]=geocode.get('xCoordinate')
            row[y]=geocode.get('yCoordinate')
            row.append('*MATCHED - TO INTERSECTION - '+geocode.get('firstStreetNameNormalized')+' AND '
                   +geocode.get('secondStreetNameNormalized'))
        else:
            row.append(geocode.get('message'))            
    else:
        row.append(geocode.get('message'))
    return row  

#The primary function for the script. Takes file name and the indexes or columns
#numbers in the input file as input. Reads lines into nested list.
def sfcoder(thefile,adnum,street,instreet,crstreet,borough,x,y):    
    records=[]
    readfile=open(thefile,"r")
    for line in readfile:
        line_list=line.strip().split(",")
        records.append(line_list)
    readfile.close()

#This dictionary contains replacements to fix bad street names before matching
    prefixes={'102 CROSS DRIVE':'102 STREET CROSSING',
                  'BEACH CHANNEL DRIVE CIRCLE':'BEACH CHANNEL DRIVE',
                  '104 STREETT':'104 STREET',
                  '125TH ST AND AMST':'125 STREET AND AMSTERDAM AVENUE',
                  '127TH STRTEET':'127 STREET',
                  '163 RD STREET':'163 STREET',
                  '163':'163 STREET',
                  '17 LANE':'17 LANE AVENUE',
                  '186 LANE AENUE':'186 LANE AVENUE',
                  '196 REET':'196 STREET',
                  '200 STTREET':'200 STREET',
                  '223 STREEET':'223 STREET',
                  '2289 EAST 2 STREE':'2289 EAST 2 STREET',
                  '37 AVENEU':'37 AVENUE',
                  '59 TH STREET':'59 STREET',
                  '70 TH STREET':'70 STREET',
                  '72 AVENUE WEST':'72 WEST AVENUE',
                  '80 TH STREET':'80 STREET',
                  '8TH AVNEUE':'8 AVENUE',
                  'AMSTERDAM AVNENUE':'AMSTERDAM AVENUE',
                  'ARDEN ROAD':'WOODS OF ARDEN ROAD',
                  'ARVERNE PROJECT':'74-15 BEACH CHANNEL DRIVE',
                  'ASPEN KNOLL WAY':'ASPEN KNOLLS WAY',
                  'ASTORIA BOULEVA':'ASTORIA BOULEVARD',
                  'ATLANTIC AENUE':'ATLANTIC AVENUE',
                  'AVENUE OF THE AME':'6 AVENUE',
                  'AVENUE OF THE AMERICAS':'6 AVENUE',
                  'BAINEBRIDGE AVENUE':'BAINBRIDGE AVENUE',
                  'BAISLEY PARK PROJECT':'116-45 GUY R BREWER BOULEVARD',
                  'BARTOW CIRCLE':'PELHAM BRIDGE ROAD',
                  'BEACH CHANNEL D':'BEACH CHANNEL DRIVE',
                  'BEACH CHANNEL DRI':'BEACH CHANNEL DRIVE',
                  'BEACH CHANNEL STREET':'BEACH CHANNEL DRIVE',
                  'BEDFOD AVENUE':'BEDFORD AVENUE',
                  'BESSEMUND ROAD':'BESSEMUND AVENUE',
                  'BESSEUMUND AVENUE':'BESSEMUND AVENUE',
                  'BLACKFORD STREE':'BLACKFORD STREET',
                  'BROOKLYN QUEENS E':'BROOKLYN QUEENS EXPRESSWAY',
                  'BROOKLYN QUEENS EXPRES':'BROOKLYN QUEENS EXPRESSWAY',
                  'BROOKLYN QUEENS':'BROOKLYN QUEENS EXPRESSWAY',
                  'CANTERBERRY AVE':'CANTERBURY AVENUE',
                  'CARISSLE PLACE':'CARLISLE PLACE',
                  'CASTLETON PARK NORTH':'185 ST MARKS PLACE',
                  'COLLEGE POINT BOULEVAR':'COLLEGE POINT BOULEVARD',
                  'COOP CITY BOULEV':'COOP CITY BOULEVARD',
                  'CRANSTAN AVENUE':'CRANSTON STREET',
                  'DONGAN HILL AVE':'DONGAN HILLS AVENUE',
                  'DONGAN HILL AVENUE':'DONGAN HILLS AVENUE',
                  'DRUMGOOLE ROAD WE':'DRUMGOOLE ROAD WEST',
                  'DRUMGOOLE ROAD':'DRUMGOOLE ROAD',
                  'EAST BEDFORD PA':'EAST BEDFORD PARK BOULEVARD',
                  'EAST BEDFORD PARK BOUL':'EAST BEDFORD PARK BOULEVARD',
                  'EAST BEDFORD PARK BOULE':'EAST BEDFORD PARK BOULEVARD',
                  'EAST MOSHOLU PA':'MOSHOLU PARKWAY',
                  'EAST OCEANA DRI':'OCEANA DRIVE EAST',
                  'EL GRANT HIGHWAY':'EDWARD L GRANT HIGHWAY',
                  'FARMERS BOUELVARD':'FARMERS BOULEVARD',
                  'FLATBUSH AVENUE EXTENS':'FLATBUSH AVENUE',
                  'FLATBUSH':'FLATBUSH AVENUE',
                  'FLATLANDS':'FLATLANDS AVENUE',
                  'FOREST PARK DRIVE EAST':'FOREST PARK DRIVE',
                  'FOREST PARK DRI':'FOREST PARK DRIVE',
                  'FOREST PARK DRIVE WEST':'FOREST PARK DRIVE',
                  'FORESTPARK DRIVE EAST':'FOREST PARK DRIVE',
                  'FRANCIS LEWIS BOULEVAR':'FRANCIS LEWISH BOULEVARD',
                  'FRANKILN AVENUE':'FRANKLIN AVENUE',
                  'G R BREWER BLVD':'GUY R BREWER BOULEVARD',
                  'GLENWOOD AVENUE':'GLENWOOD ROAD',
                  'GLENWOOED':'GLENWOOD ROAD',
                  'GRAND CENTRAL PAR':'GRAND CENTRAL PARKWAY',
                  'GRANDCENTRAL PARK':'GRAND CENTRAL PARKWAY',
                  'GUY R BREWER BOUL':'GUY R BREWER BOULEVARD',
                  'HARDING EXPRESS':'HORACE HARDING EXPRESSWAY',
                  'HAWK STONE AVENUE':'HAWKSTONE STREET',
                  'HENLEY AVENUE':'HENLEY ROAD',
                  'HICKSVILLE AVENUE':'HICKSVILLE ROAD',
                  'HICKVILLE ROAD':'HICKSVILLE ROAD',
                  'HICKVILLE':'HICKSVILLE ROAD',
                  'HILLSIDEM AVENUE':'HILLSIDE AVENUE',
                  'HUTCHINSON RIVER PARKW':'HUTCHINSON RIVER PARKWAY',
                  'HUTCHINSON RIVER PARKWA':'HUTCHINSON RIVER PARKWAY',
                  'JAMACIA AVENUIE':'JAMAICA AVENUE',
                  'JAMAIC AVENUE':'JAMAICA AVENUE',
                  'JEFFERSON ST':'JEFFERSON STREET',
                  'JERESEY STREET':'JERSEY STREET',
                  'JERESY STREET':'JERSEY STREET',
                  'LOUIS NINE BLVDE':'LOUIS NINE BOULEVARD',
                  'MARTIN LUTHER KING':'MARTIN LUTHER KING PLACE',
                  'MC GUINNESS BOULE':'MCGUINNESS BOULEVARD',
                  'MAYVILLE AVENUE':'MAYVILLE STREET',
                  'METROPOLITAN AVEN':'METROPOLITAN AVENUE',
                  'MORNINGSIDE':'MORNINGSIDE AVENUE',
                  'MORNINGSIDE AVEN':'MORNINGSIDE AVENUE',
                  'MORRISS STREET':'MORRIS STREET',
                  'MOTHER GASTON B':'MOTHER GASTON BOULEVARD',
                  'MOTHERGASTON BL':'MOTHER GASTON BOULEVARD',
                  'MOTHERGASTON':'MOTHER GASTON BOULEVARD',
                  'NORTH CONDUIT A':'NORTH CONDUIT AVENUE',
                  'NORTH CONDUIT':'NORTH CONDUIT AVENUE',
                  'OAKELY STREET':'OAKLEY STREET',
                  'PENNSYLVANIA AVEN':'PENNSYLVANIA AVENUE',
                  'PITKIN AVENUNE':'PITKIN AVENUE',
                  'PORSPECT AVENUE':'PROSPECT AVENUE',
                  'POWELLS COVE BOUL':'POWELLS COVE BOULEVARD',
                  'PROSPECT PARK SOUTH WES':'PROSPECT PARK SOUTHWEST',
                  'PROSPECT PARK SOUTHWES':'PROSPECT PARK SOUTHWEST',
                  'PROSPECT':'PROSPECT PARK SOUTHWEST',
                  'QUEENS BOLLEVARD':'QUEENS BOULEVARD',
                  'QUEENS BOUELVARD':'QUEENS BOULEVARD',
                  'REDERN AVENUE':'REDFERN AVENUE',
                  'REFERN AVENUE':'REDFERN AVENUE',
                  'RENSSELAER AVEN':'RENSSELAER AVENUE',
                  'REV JAMES E POLITE AVE':'REV JAMES E POLITE AVENUE',
                  'REVERAND JAMES POLITE':'REV JAMES E POLITE AVENUE',
                  'RIEGALMAN BOARDWALK WE':'RIEGELMANN BOARDWALK',
                  'RIEGALMAN BOARDWALK WES':'RIEGELMANN BOARDWALK',
                  'RIEGELMAN BOARDWALK EA':'RIEGALMANN BOARDWALK',
                  'RIEGELMAN BOARDWALK EAS':'RIEGALMANN BOARDWALK',
                  'RIVER BOULEVARD':'RIVERSIDE BOULEVARD',
                  'RIVERSIDE BOULEVA':'RIVERSIDE BOULEVARD',
                  'ROACKAWAY BOULEVARD':'ROCKAWAY BEACH BOULEVARD',
                  'ROCKAWAY BEACH BOULEV':'ROCKAWAY BEACH BOULEVARD',
                  'ROCKAWAY BEACH BO':'ROCKAWAY BEACH BOULEVARD',
                  'ROCKAWAY BEACH BOULEVA':'ROCKAWAY BEACH BOULEVARD',
                  'ROCKAWAY BOUELVARD':'ROCKAWAY BEACH BOULEVARD',
                  'ROCKAWAY FREEWA':'ROCKAWAY FREEWAY',
                  'ROCKAWAY POINT BOULEVA':'ROCKAWAY POINT BOULEVARD',
                  'ROCKAWAY BOUILEV':'ROCKAWAY POINT BOULEVARD',
                  'ROCKNE AVENUE':'ROCKAWAY AVENUE',
                  'ROCKWAY FREEWAY':'ROCKAWAY FREEWAY',
                  'ROOSEVELT ISLAND BRIDG':'ROOSEVELT ISLAND BRIDGE',
                  'SAINT PAULS COU':'SAINT PAULS COURT',
                  'SCHIEFELIN AVEN':'SCHIEFELIN AVENUE',
                  'SEAGIRT BOULEVA':'SEAGIRT BOULEVARD',
                  'SEAGIRT BOULVERAD':'SEAGIRT BOULEVARD',
                  'SHARROTTS AVE':'SHARROTTS ROAD',
                  'SHORE FRONT PARKW':'SHORE FRONT PARKWAY',
                  'ST NICHOLAS AVE 3':'ST NICHOLAS AVENUE',
                  'ST NICHOLAS':'ST NICHOLAS AVENUE',
                  'ST. JAMES PLACES':'ST JAMES PLACE',
                  'STRICTLAND AVENUE':'STRICKLAND AVENUE',
                  'THROGMORTAN AVENUE':'THROGMORTON AVENUE',
                  'TIMBER RIDGE RO':'TIMBER RIDGE DRIVE',
                  'TIMBER RIDGE ROAD':'TIMBER RIDGE DRIVE',
                  'TIMBERRIDGE DRI':'TIMBER RIDGE DRIVE',
                  'TIMBERRIDGE SRIVE':'TIMBER RIDGE DRIVE',
                  'UNIVERSITY AVE':'UNIVERSITY AVENUE',
                  'UNIVERSITY AVEN':'UNIVERSITY AVENUE',
                  'VANCORTLANDT AVENUE WE':'VAN CORTLANDT AVENUE',
                  'VANCORTLANDT PARK WEST':'VAN CORTLANDT PARK',
                  'VANDERBILT':'VANDERBILT AVENUE',
                  'VANERVEER STREET':'VANDERVEER STREET',
                  'VERMONT PLACE':'VERMONT STREET',
                  'VERMONT':'VERMONT STREET',
                  'VETERANS ROAD WES':'VETERANS ROAD',
                  'WAINWRIGHT AVEN':'WAINWRIGHT AVENUE',
                  'WELLHOUSE DRVE':'WELLHOUSE DRIVE',
                  'WEST 148 STEEET':'148 STREET',
                  'WEST BEDFORD PARK BOUL':'WEST BEDFORD PARK BOULEVARD',
                  'WEST OCEANA DRI':'WEST OCEANA DRIVE',
                  'WEST SERVICE RO':'WEST SERVICE ROAD',
                  'WESTCHESTER SQUAR':'WESTCHESTER SQUARE',
                  'WESTMINSTER RO':'WESTMINSTER ROAD',
                  'WESTMINISTER RO':'WESTMINSTER ROAD',
                  'WESTMINISTER ROAD':'WESTMINSTER ROAD',
                  'WILLETS POINT BOULEVAR':'WILLETS POINT BOULEVARD',
                  'WOLWORTH AVENUE':'WOOLWORTH AVENUE',
                  'WOODYCREST AVEN':'WOODYCREST AVENUE'}

#This dictionary contains replacements to fix unmatched intersections after matching   
    postfixes={'WEST   58 STREET & COLUMBUS CIRCLE DO NOT INTERSECT':['989160','218920'],
           'RODMANS NECK ROAD & CITY ISLAND ROAD DO NOT INTERSECT':['1038910','252190'],
           '1 AVENUE & EAST  113 STREET DO NOT INTERSECT':['1001664','228614'],
           '111 AVENUE &  209 STREET DO NOT INTERSECT':['1054335','196229'],
           '112 AVENUE &  210 STREET DO NOT INTERSECT':['1054469','196266'],
           '115 AVENUE &  232 STREET DO NOT INTERSECT':['1059768','193389'],
           '221 STREET &  111 AVENUE DO NOT INTERSECT':['1054850','199591'],
           '233 PLACE & HARDING EXPRESSWAY DO NOT INTERSECT':['1052474','212316'],
           '57 STREET &   19 AVENUE DO NOT INTERSECT':['988950','166146'],
           '64 STREET &   54 AVENUE DO NOT INTERSECT':['1011591','204758'],
           '80 AVENUE &  251 STREET DO NOT INTERSECT':['1061706','210085'],
           '83 AVENUE &  171 STREET DO NOT INTERSECT':['1041455','200830'],
           '85 AVENUE & NORMAL ROAD DO NOT INTERSECT':['1038960','198934'],
           '9 STREET & HUNTINGTON STREET DO NOT INTERSECT':['983935','185547'],
           '92 STREET &   58 AVENUE DO NOT INTERSECT':['1020629','207079'],
           '96 STREET &   88 AVENUE DO NOT INTERSECT':['1026160','191737'],
           'ALBEE SQUARE & FULTON STREET DO NOT INTERSECT':['988809','190657'],
           'ARLINGTON AVENUE & SOUTH AVENUE DO NOT INTERSECT':['938102','170977'],
           'ATLANTIC AVENUE &  126 STREET DO NOT INTERSECT':['1033621','192736'],
           'BAY   53 STREET & DEAD END DO NOT INTERSECT':['987385','151614'],
           'BEACH   15 STREET & SEAGIRT BOULEVARD DO NOT INTERSECT':['1053982','156275'],
           'BEACH   56 PLACE & SHORE FRONT PARKWAY DO NOT INTERSECT':['1043800','154331'],
           'BEACH   56 STREET & SHORE FRONT PARKWAY DO NOT INTERSECT':['1043800','154331'],
           'BEACH   60 STREET & BEACH CHANNEL DRIVE DO NOT INTERSECT':['1042652','155703'],
           'BEACH  109 STREET & OCEAN PROMENADE DO NOT INTERSECT':['1031470','150639'],
           'BEACH CHANNEL DRIVE & BEACH CHANNEL DRIVE DO NOT INTERSECT':['1039867','155215'],
           'BOARDWALK & BEACH    9 STREET DO NOT INTERSECT':['1055432','155973'],
           'BOARDWALK & BEACH   28 STREET DO NOT INTERSECT':['1050816','155129'],
           'BOSTON ROAD & CLAREMONT PARKWAY DO NOT INTERSECT':['1013530','243483'],
           'CARMINE STREET & VARICK STREET DO NOT INTERSECT':['982795','205031'],
           'CROSS BAY BOULEVARD & NORTH CHANNEL BRIDGE DO NOT INTERSECT':['1029574','175615'],
           'EAST   11 STREET & AVENUE D DO NOT INTERSECT':['991207','203610'],
           'EAST   26 STREET & BEVERLEY ROAD DO NOT INTERSECT':['997308','174224'],
           'EAST  114 STREET &    2 AVENUE DO NOT INTERSECT':['1001155','229189'],
           'EAST  152 STREET & WESTCHESTER AVENUE DO NOT INTERSECT':['1008005','236720'],
           'EAST DRIVE & LINCOLN ROAD DRIVE DO NOT INTERSECT':['994274','179735'],
           'EASTERN PARKWAY & FLATBUSH AVENUE DO NOT INTERSECT':['992834','184519'],
           'FLATBUSH AVENUE & EASTERN PARKWAY DO NOT INTERSECT':['992834','184519'],
           'FOREST PARK DRIVE &   88 LANE DO NOT INTERSECT':['1023749','194577'],
           'FULTON STREET & ALBEE SQUARE DO NOT INTERSECT':['988809','190657'],
           'HANSON PLACE & FLATBUSH AVENUE DO NOT INTERSECT':['990330','188863'],
           'LIBERTY AVENUE &  153 STREET DO NOT INTERSECT':['1039518','193993'],
           'MANHATTAN BRIDGE & MARKET SLIP DO NOT INTERSECT':['985990','197914'],
           'NEW DORP LANE & SOUTH RAILROAD AVENUE DO NOT INTERSECT':['951905','148490'],
           'RIVERSIDE DRIVE & WEST  176 STREET DO NOT INTERSECT':['999979','248510'],
           'RODMANS NECK ROAD & CITY ISLAND ROAD DO NOT INTERSECT':['1038748','252718'],
           'SAINT MARKS AVENUE & TROY AVENUE DO NOT INTERSECT':['1001952','185003'],
           'TROY AVENUE & SAINT MARKS AVENUE DO NOT INTERSECT':['1001952','185003'],
           'VICTORY BOULEVARD & SAINT PAULS AVENUE DO NOT INTERSECT':['962517','171775'],
           'WASHINGTON PLACE & POST AVENUE DO NOT INTERSECT':['947395','169587'],
           'WEST DRIVE &    3 STREET DRIVE DO NOT INTERSECT':['991854','182576'],
           'KING PLACE & MARCY AVENUE DO NOT INTERSECT':['998654','190491'],
           'MARCY AVENUE & KING PLACE DO NOT INTERSECT':['998654','190491'],
           'TOMPKINS AVENUE & KING PLACE DO NOT INTERSECT':['999442','190604'],
               'TYRELLAN AVENUE & VETERANS ROAD DO NOT INTERSECT':['920250','131600'],
               'WEST    8 STREET & RIEGELMANN BOARDWALK DO NOT INTERSECT':['990740','148595'],
               'WEST   63 STREET & AMSTERDAM AVENUE DO NOT INTERSECT':['988182','220868']}
    
#Append header for match result column, then replace street names in the record list with
#correct names that appear in the api so these records can be matched. if index > street-1
#saves time as it only will search through the indexes at the end of the file    
    records[0].append('match_result') 

##    replacements={'102 CROSS DRIVE':'102 STREET CROSSING',
##                  'BEACH CHANNEL DRIVE CIRCLE':'BEACH CHANNEL DRIVE'}

    for row in records:
        for index, item in enumerate(row):
            if index > street-1:
                if item in prefixes:
                    row[index]=prefixes.get(item)

#Loop through the records and pass the relevant values to the geocoder functions in order                   
#from most to least ideal outcome: address match, block midpoint, and street intersection.
#The sub-if statements will attempt to rematch if the ideal is not found; before passing
#passing the info back the error message from the last process is removed.                    
    counter=0   
    for row in records[1:]:        
        if row[adnum] != '':
            getaddress(row,adnum,street,borough,x,y)
            if row[-1].startswith('*MATCHED')==False:
                row.pop()
                getblock(row,street,instreet,crstreet,borough,x,y)
                if row[-1].startswith('*MATCHED')==False:
                    row.pop()
                    getintersection(row,street,instreet,borough,x,y)
                    if row[-1].startswith('*MATCHED')==False:
                        row.pop()
                        getintersection(row,street,crstreet,borough,x,y)                                      
        elif row[street] !='':
            getblock(row,street,instreet,crstreet,borough,x,y)
            if row[-1].startswith('*MATCHED')==False:
                row.pop()
                getintersection(row,street,instreet,borough,x,y)
                if row[-1].startswith('*MATCHED')==False:
                    row.pop()
                    getintersection(row,street,crstreet,borough,x,y)  
        elif row[instreet] !='':
            getintersection(row,instreet,crstreet,borough,x,y)
        else:
            row.append('INSUFFICIENT DATA')
        counter=counter+1
        if counter % 500 ==0:
            print counter, "records have been processed so far."

    print "A total of", counter, "records have been processed."

#Correct common mismatches by looping back through the geocoded records and replacing
#these instances with correct coordinates.    
##    fixes={'WEST   58 STREET & COLUMBUS CIRCLE DO NOT INTERSECT':['989160','218920'],
##           'RODMANS NECK ROAD & CITY ISLAND ROAD DO NOT INTERSECT':['1038910','252190']}
    
    for row in records:
        if row[-1] in postfixes:
            xy=postfixes.get(row[-1])
            row[x]=xy[0]
            row[y]=xy[1]
            row[-1]='*MATCHED - MANUAL CORRECTION FOR ERROR'
            
#Write the records out to a new file with a name modified from the original          
    writefile=open('matched_'+thefile,"w")
    for row in records:        
        writefile.writelines(",".join(row)+"\n")   
    writefile.close()


            
